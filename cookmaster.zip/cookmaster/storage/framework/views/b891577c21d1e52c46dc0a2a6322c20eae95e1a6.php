
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content='maximum-scale=1.0, initial-scale=1.0, width=device-width' name='viewport'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CookMaster</title>
    <style>
        body{
            background-image: url('<?php echo e(asset('storage/background/bg-4.png')); ?>');
            background-size: cover;
            background-repeat: repeat;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
        }
        .pagination{
            margin-top: 10px;
            clear:left;
        }
        nav{
            margin-bottom: 20px;
        }
        .log-reg{
            margin: 5px;
        }
        .log-reg a{
            color: gray;
        }
        .form-inline{
            width: 31.8vw;
        }
        nav .btn-primary{
            width: 100px;
            margin: 2px;
        }
        .adm-btns{
            margin-bottom: 20px;
        }
        img{
            height: 200px;
            width: 200px;
            margin: auto;
        }
        @media  screen and (max-width: 800px) {
            .card{
                margin: auto;
            }
            .adm-btns{
                text-align: center;
                display: block;
            }
            .btn{
                margin-top: 5px;
            }
        }

        .card>.card:hover{
            transform: scale(1.002);
            box-shadow: 0 10px 20px rgba(0,0,0,.12), 0 4px 8px rgba(0,0,0,.06);
        }
    </style>
    <script>
        $(document).ready(function(){
            $("#myBtn").click(function(){
                var choose = $("#choose").val();
                var str = $("#search").val();
                if(str == ""){
                    alert("Search is Empty");
                } else{
                    if(choose == 'recipe'){
                        window.location = "/recipe/name/"+str;
                    } else if(choose == 'ingredient'){
                        window.location = "/recipe/ingredient/"+str;
                    } else if(choose == 'category'){
                        window.location = "/recipe/category/"+str;
                    }
                }
            });
            $("#edit_recipe").click(function(event) {
                event.stopPropagation();
            });
        });
    </script>
</head>
<body>
    
    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
        <div class="container">
            

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">
                    <input class="form-control mr-sm-2 col-lg-6" type="text" placeholder="Search" id="search" name="search" aria-label="Search">
                    <select name="choose" id="choose">
                        <option value="recipe">Recipe</option>
                        <option value="ingredient">Ingredient</option>
                        <option value="category">Category</option>
                    </select>
                    <button class="btn btn-primary my-2 my-sm-0" type="button" id="myBtn">Search</button>
                </ul>
                <ul class="navbar-nav mr-auto">
                    <a class="navbar-brand  text-center" href="<?php echo e(url('/')); ?>">
                        <font size ="6px">cook master</font><br><font size="3px"><i>anyone can cook</i></font>
                    </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
                </ul>
                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/profile/<?php echo e(Auth::user()->id); ?>">Profile</a>
                                <a class="dropdown-item" href="/subscriptions">Your Subscriptions</a>
                                <a class="dropdown-item" href="/transaction-history">Transaction History</a>
                                <a class="dropdown-item" href="/top-up">Top Up</a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        
                        <?php if(\Auth::user()->role_id == 1): ?>
                            <button type="button" class="btn btn-primary mr-sm-2" onclick="window.location.href='/subscriptions'">Subscription</button>
                        <?php elseif(\Auth::user()->role_id==2||\Auth::user()->role_id==3): ?>
                            <button type="button" class="btn btn-primary mr-sm-2" onclick="window.location.href='/earning'">Earnings</button>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <ul class="nav justify-content-center" style="background-color: #e3f2fd;">
            <li>
                <a class="nav-link" href="/home">HOME</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/recipe/best-recipe">BEST RECIPE</a>
            </li>
            <li>
                <a class="nav-link" href="/top-chefs">TOP CHEFS</a>
            </li>
            <li>
                <a class="nav-link" href="/top-contributors">TOP CONTRIBUTORS</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/guest-chef">GUEST CHEF</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/community">COMMUNITY</a>
            </li>
        </div>

        <br>
        <div class="container">
        <div class="card">
            <div class="card-header"><h5>Best Recipes: </h5></div>
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner bg-light">
                <br>
                  <div class="carousel-item active" onclick="window.location='/recipe/view-recipe/<?php echo e($best_recipes[0]->id); ?>'">
                    <img class="d-block w-200" src="<?php echo e(asset('storage/'.$best_recipes[0]->image)); ?>" alt="<?php echo e($best_recipes[0]->name); ?>">
                    <div class="d-block w-200 h4" style="text-align: center;"><?php echo e($best_recipes[0]->name); ?></div>
                  </div>
                  <div class="carousel-item" onclick="window.location='/recipe/view-recipe/<?php echo e($best_recipes[1]->id); ?>'">
                    <img class="d-block w-200" src="<?php echo e(asset('storage/'.$best_recipes[1]->image)); ?>" alt="<?php echo e($best_recipes[1]->name); ?>">
                    <div class="d-block w-200 h4" style="text-align: center;"><?php echo e($best_recipes[1]->name); ?></div>
                  </div>
                  <div class="carousel-item" onclick="window.location='/recipe/view-recipe/<?php echo e($best_recipes[2]->id); ?>'">
                    <img class="d-block w-200" src="<?php echo e(asset('storage/'.$best_recipes[2]->image)); ?>" alt="<?php echo e($best_recipes[2]->name); ?>">
                    <div class="d-block w-200 h4" style="text-align: center;"><?php echo e($best_recipes[2]->name); ?></div>
                  </div>
                </div>
                <a class="carousel-control-prev bg-secondary" href="#carouselExampleControls" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only bg-dark">Previous</span>
                </a>
                <a class="carousel-control-next bg-dark" href="#carouselExampleControls" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
        </div>

        <?php if(auth()->guard()->check()): ?>   
            
            <?php if(\Auth::user()->role_id==2||\Auth::user()->role_id==3): ?>
            <br>
            <div class="container">
            <div class="row">
                <div class="card col-md-3 bg-light ml-5" style="width: 40rem;">
                    <div class="card-body"><h5><strong>Report:</strong></h5><br>
                        <p class="card-text">
                            Balance : <br>Rp <?php echo e($user->balance); ?><br>
                            <br>
                            Earnings : <br>Rp <?php echo e($earnings); ?><br>
                            <br>
                            Subscribers :<br> <?php echo e($total_subscriber); ?><br>
                        </p>
                        <br>
                        <div class="container adm-btns">
                            <button type="button" class="btn btn-primary" onclick="window.location='/new-recipe/'">Add New Recipe</button>
                        </div>
                        <div class="container adm-btns">
                            <button type="button" class="btn btn-primary" onclick="window.location='/profile/<?php echo e($user->id); ?>#recipes'">View Your Recipes</button>
                        </div>
                    </div>
                </div>
                <?php if(!empty($my_recipes)): ?>
                <div class="card col-md-3 bg-light ml-5" onclick="window.location.href='/recipe/view-recipe/<?php echo e($my_recipes->id); ?>'" style="width: 40rem;">                    
                    <div class="card-body"><h5><strong>Latest Recipe:</strong></h5></div>
                    <img class="card-image-top" src="<?php echo e(asset('storage/'.$my_recipes->image)); ?>"> 
                    <div class="card-body">   
                    <div class="card-title"><strong><?php echo e($my_recipes->name); ?></strong></div>
                    <div class="card-text">        
                        Average rating  : <br>
                            <?php echo e($my_recipes->average_rating); ?> / 5.00 <br> from <?php echo e($my_recipes->review_count); ?> people <br><br>
                        <div class="container adm-btns">
                            <button type="button" class="btn btn-primary" id="edit_recipe" onclick="window.location='/edit-recipe/<?php echo e($my_recipes->id); ?>'">Edit Recipe</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="card col-md-3 bg-light ml-5">
                <div class="card-body"><h5><strong>Latest Recipe:</strong></h5></div>
                <div class="card-body"><center>You don't have any recipes.</center></div>
            </div>
            
            <?php endif; ?>
            </div>
            <?php elseif(\Auth::user()->role_id==1): ?>
            <br>
            <div class="container">
                <div class="row">
                    <!-- Recipe from followings -->
                    <div class="card ml-3">
                        <div class="card-header h5">Latest recipes from people you follow</div>
                        <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card bg-light" style="width: 25rem;">
                            <div class="card-body"><h5><strong><?php echo e($recipe->name); ?> </strong></h5></div>
                            <img class="card-image-top" src="<?php echo e(asset('storage/'.$recipe->image)); ?>"> 
                            <div class="card-body">
                                <div class="card-title"><strong>From <a href="/profile/<?php echo e($recipe->user->id); ?>"><?php echo e($recipe->user->name); ?></a></strong></div>
                                <div class="card-text">        
                                    Average rating  : <br>
                                        <?php echo e($recipe->average_rating); ?> / 5.00 <br> from <?php echo e($recipe->review_count); ?> people <br><br>
                                    <div class="container adm-btns">
                                        <button type="button" class="btn btn-primary" onclick="window.location.href='/recipe/view-recipe/<?php echo e($recipe->id); ?>'">View Recipe</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="card-body" style="width: 25rem;">You are not following anyone.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Recipes from subscriptions -->
                    <div class="card ml-2">
                        <div class="card-header h5">Latest recipes from your subscriptions</div>
                        <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card bg-light" style="width: 25rem;">
                            <div class="card-body"><h5><strong><?php echo e($recipe->name); ?></strong></h5></div>
                            <img class="card-image-top" src="<?php echo e(asset('storage/'.$recipe->image)); ?>"> 
                            <div class="card-body">
                                <div class="card-title"><strong>From <a href="/profile/<?php echo e($recipe->user->id); ?>"><?php echo e($recipe->user->name); ?></a></strong></div>
                                <div class="card-text">        
                                    Average rating  : <br>
                                        <?php echo e($recipe->average_rating); ?> / 5.00 <br> from <?php echo e($recipe->review_count); ?> people <br><br>
                                    <div class="container adm-btns">
                                        <button type="button" class="btn btn-primary" onclick="window.location.href='/recipe/view-recipe/<?php echo e($recipe->id); ?>'">View Recipe</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="card-body" style="width: 25rem;">You don't have any active subscription.</div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card col-md-3 bg-light ml-2 pb-4" style="width: 40rem; height: fit-content;">
                        <div class="card-body"><h5><strong>Your Account:</strong></h5><br>
                            <p class="card-text">
                                Balance : <br>Rp. <?php echo e($user->balance); ?><br>
                                <br>
                                Lifetime topup :<br>Rp. <?php echo e($user->lifetime_topup); ?><br>
                                <br>
                                <button class="btn btn-primary" onclick="window.location='/top-up'">Top Up</button>
                            </p>
                    </div>
                </div>
            </div>

            </div>
            <?php endif; ?>
        <?php endif; ?>
        <br>
    </div>
</body>
</html>
<?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/welcome.blade.php ENDPATH**/ ?>