<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Recipes with ').$filter.': '.$query); ?></div>

                <div class="card-body">
                    <div class="alert alert-warning"><?php echo e(__('You are viewing filtered recipes page!')); ?></div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div>Title: <?php echo e($recipe->name); ?></div>
                        <div>Author: <?php echo e($recipe->user->name); ?></div>
                        <div>Ingredients:</div>
                        <div class="card">
                            <?php $__empty_2 = true; $__currentLoopData = $recipe->recipeDetailIngredient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="card-body"><?php echo e($ingredient->amount); ?> <?php echo e($ingredient->name); ?> <?php if(!empty($ingredient->notes)): ?> (<?php echo e($ingredient->notes); ?>) <?php endif; ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="card-body"><?php echo e(__('No ingredient added yet.')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div>Steps:</div>
                        <div class="card">
                            <?php $__empty_2 = true; $__currentLoopData = $recipe->recipeDetailStep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="card-body"><?php echo e($step->step_no); ?>. <?php echo e($step->text); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="card-body"><?php echo e(__('No steps added yet.')); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="card"><?php echo e(__('No results')); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_recipes_test.blade.php ENDPATH**/ ?>