
<?php $__env->startSection('namapage'); ?>
    class='background-2'
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box-content-form">
<div class="container">
    <div class="row">
        <div class="card">
            <div class="card-header" id="recipe">
                Edit Recipe - <?php echo e($recipe->name); ?>

                <button class="btn btn-primary float-right" onclick="window.location='/profile/<?php echo e(Auth::user()->id); ?>'">Done</button>
            </div>
            <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <?php if(session('recipe_success')): ?>
            <div class="alert alert-success"><?php echo e(session('recipe_success')); ?></div>
            <?php endif; ?>
            <div class="card-body" style="width: 100%;">
                <?php if($errors->any() && session('error_type')=='edit_recipe'): ?>
                    <div class="alert alert-danger">All recipe details must be filled.</div>
                <?php endif; ?>
                <div class="card-image"><img class="img-thumbnail" src="<?php echo e(asset('storage/'.$recipe->image)); ?>" alt="recipe-img"></div>
                <form class="col-md-10" action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                    <input type="hidden" name="edit" value="recipe">
                    
                    <div class="form-group">
                        <label class="col-md-4" for="name">Recipe Name: </label>
                        <input class="col-md-6" type="text" name="name" value="<?php echo e($recipe->name); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-4" for="recipe_type">Recipe Type: </label>
                        <select class="col-md-6" name="recipe_type" id="type">
                            <option <?php if($recipe->recipe_type==1): ?> selected <?php endif; ?> value="1">Free Recipe</option>
                            <option <?php if($recipe->recipe_type==2): ?> selected <?php endif; ?> value="2">Paid Recipe</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-md-4" for="category">Recipe Category: </label>
                        <select class="col-md-6" name="category" id="category">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($recipe->recipe_category_id == $category->id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button class="btn btn-sm btn-success float-right" type="submit" name="recipe_id" value="<?php echo e($recipe->id); ?>">Save Changes</button>
                </form>
                <form action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                    <input type="hidden" name="delete" value="recipe">

                    <button class="btn btn-danger" type="submit" name="recipe_id" value="<?php echo e($recipe->id); ?>">Delete</button>
                </form>
            </div>

            <div class="card" id="ingredient">
                <div class="card-header">Ingredients</div>
                <?php if($errors->any() && session('error_type')=='new_ingredient'): ?>
                    <div class="alert alert-danger">Ingredient name must be filled.</div>
                <?php endif; ?>
                <?php if($errors->any() && session('error_type')=='edit_ingredient'): ?>
                    <div class="alert alert-danger">Can't update ingredient. Ingredient name must not be empty.</div>
                <?php endif; ?>
                <?php if(session('ingredient_success')): ?>
                    <div class="alert alert-success"><?php echo e(session('ingredient_success')); ?></div>
                <?php endif; ?>
                <div class="card-body">
                    <?php $__currentLoopData = $recipe->recipeDetailIngredient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- form to update each existing ingredient -->
                    <div class="row p-1">
                        <form action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="edit" value="ingredient">
                            <input type="hidden" name="ingredient_id" value="<?php echo e($ingredient->id); ?>">
                            <input type="text" name="name" value="<?php echo e($ingredient->name); ?>" placeholder="name">
                            <input type="text" name="amount" value="<?php echo e($ingredient->amount); ?>" placeholder="amount (optional)">
                            <input type="text" name="notes" value="<?php echo e($ingredient->notes); ?>" placeholder="notes (optional)">
                            <button class="btn btn-success mr-1" type="submit" name="recipe_id" value="<?php echo e($recipe->id); ?>">Update</button>
                        </form>
                        <form action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="delete" value="ingredient">
                            <input type="hidden" name="ingredient_id" value="<?php echo e($ingredient->id); ?>">

                            <button class="btn btn-danger" type="submit" name="recipe_id" value="<?php echo e($recipe->id); ?>">Delete</button>
                        </form>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row p-1">
                        <!-- form to add new ingredient -->
                        <form action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="add" value="ingredient">
                            <input type="text" name="name" id="name" placeholder="ingredient name">
                            <input type="text" name="amount" id="amount" placeholder="amount, e.g. 3 tbsp">
                            <input type="text" name="notes" id="notes" placeholder="notes, e.g. minced">
                            <button type="submit" class="btn btn-primary" name="recipe_id" value="<?php echo e($recipe->id); ?>">+ Add</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="step">Steps</div>
                <div class="card-body">
                    <?php if($errors->any() && session('error_type')=='edit_step'): ?>
                        <div class="alert alert-danger">Can't update step. The step must be filled.</div>
                    <?php endif; ?>
                    <?php if($errors->any() && session('error_type')=='new_step'): ?>
                        <div class="alert alert-danger">Can't add step. The step must be filled.</div>
                    <?php endif; ?>
                    <?php if(session('step_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('step_success')); ?></div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $recipe->recipeDetailStep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- form to edit each step -->
                    <div class="row p-1" style="vertical-align: middle;">
                        <div class="col-md-1"><?php echo e($step->step_no); ?>. </div>
                        <div style="display: inline-table;">
                            <form action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post" >
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                <input type="hidden" name="edit" value="step">
                                <input type="hidden" name="step_id" value="<?php echo e($step->id); ?>">
                                <input type="hidden" name="step_no" value="<?php echo e($step->step_no); ?>">
                                <textarea cols="70" rows="5" class="col-md-12" name="text" value="<?php echo e($step->text); ?>" style="display: flexbox;"><?php echo e($step->text); ?></textarea>
                                <button class="btn btn-success mr-1 float-left" type="submit" name="recipe_id" value="<?php echo e($recipe->id); ?>">Update</button>
                            </form>
                            <form class="float-left" action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                <input type="hidden" name="delete" value="step">
                                <input type="hidden" name="step_id" value="<?php echo e($step->id); ?>">
                                <input type="hidden" name="step_no" value="<?php echo e($step->step_no); ?>">
                                <button class="btn btn-danger" type="submit" name="recipe_id" value="<?php echo e($recipe->id); ?>">Delete</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row p-1">
                        <div class="col-md-1"><?php echo e(count($recipe->recipeDetailStep)+1); ?>.</div>
                        <form action="/edit-recipe/<?php echo e($recipe->id); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <input type="hidden" name="add" value="step">
                            <input type="hidden" name="recipe_id" id="recipe_id" value="<?php echo e($recipe->id); ?>">
                            
                            <input type="text" name="text" id="text" placeholder="add new step . . .">
                            <div class="row">
                                <img id="image_show" src="">
                                <label for="upload-file" class="browse-label">Image</label>
                                <br><input type="file" class="btn btn-light form-control-file" id="upload-file" name="image" onchange="readURL(this)">
                            </div>
                            
                            <button class="btn btn-primary" type="submit">+ Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/edit_recipe.blade.php ENDPATH**/ ?>