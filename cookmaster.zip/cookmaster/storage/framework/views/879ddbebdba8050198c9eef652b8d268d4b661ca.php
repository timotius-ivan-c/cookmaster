
<?php $__env->startSection('namapage'); ?>
    class="background-4"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>

<div class="container">
  <div class="row align-items-center">
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[0]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[0]->image)); ?>" alt="<?php echo e($recipes[0]->name); ?>" class="img-grid">
      </a>
    </div>
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[1]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[1]->image)); ?>" alt="<?php echo e($recipes[1]->name); ?>" class="img-grid">
      </a>
    </div>
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[2]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[2]->image)); ?>" alt="<?php echo e($recipes[2]->name); ?>" class="img-grid">
      </a>
    </div>
  </div>
  <div class="row align-items-center">
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[3]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[3]->image)); ?>" alt="<?php echo e($recipes[3]->name); ?>" class="img-grid">
      </a>
    </div>
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[4]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[4]->image)); ?>" alt="<?php echo e($recipes[4]->name); ?>" class="img-grid">
      </a>
    </div>
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[5]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[5]->image)); ?>" alt="<?php echo e($recipes[5]->name); ?>" class="img-grid">
      </a>
    </div>
  </div>
  <div class="row align-items-center">
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[6]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[6]->image)); ?>" alt="<?php echo e($recipes[6]->name); ?>" class="img-grid">
      </a>
    </div>
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[7]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[7]->image)); ?>" alt="<?php echo e($recipes[7]->name); ?>" class="img-grid">
      </a>
    </div>
    <div class="col">
      <a href="/recipe/<?php echo e($recipes[8]->id); ?>">
        <img src="<?php echo e(asset('storage/'.$recipes[8]->image)); ?>" alt="<?php echo e($recipes[8]->name); ?>" class="img-grid">
      </a>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/community.blade.php ENDPATH**/ ?>