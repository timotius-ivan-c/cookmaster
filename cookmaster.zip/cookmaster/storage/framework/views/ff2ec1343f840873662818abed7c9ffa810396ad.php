
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box-content-topup">
<div class="container">
    <div class="row">
        <div class="card-topup bg-light" style="width: 20rem;">
            <div class="card-body">
                <h5 class="card-title">User Information</h5>
                <p class="card-text">Name : <br> <?php echo e($data->username); ?><br></p>
                <p class="card-text">Balance : <br> <?php echo e($data->balance); ?><br></p>
                <p class="card-text">Tier : <br><?php echo e($data->tier_name); ?><br></p>
                <p class="card-text">Role : <br> <?php echo e($data->role); ?></p>
            </div>
        </div>
    </div>
    <br>
    <br>
    <div class="row">
        <div class="card-topup bg-light" style="width: 20rem;">
            <div class="card-body">
                <h5 class="card-title">TOP UP FORM</h5>
                <form action='/top-up' method='post'>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo e($data->user_id); ?>">
                        <label for="amount">Amount:</label>
                        <input type="text" name="amount" class="form-control" id="amount" placeholder="Enter amount">
                        <?php if($errors->any()): ?>
                                    <div class="errors"><?php echo e(implode('', $errors->get('amount'))); ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Top Up</button>
                    <button type="reset" class="btn btn-danger" onclick="history.back()">Cancel</button>
                </form>
            </div>
        </div>
    </div>
    
    
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_topup_page.blade.php ENDPATH**/ ?>