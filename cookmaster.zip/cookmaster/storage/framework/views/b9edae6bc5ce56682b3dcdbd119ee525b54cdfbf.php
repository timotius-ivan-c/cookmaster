
<?php $__env->startSection('content'); ?>

<div class="container" style="margin-bottom: 20px">
    <ul class="nav justify-content-center" style="background-color: #e3f2fd;">
        <li>
            <a class="nav-link" href="/home">HOME</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/recipe/best-recipe">BEST RECIPE</a>
        </li>
        <li>
            <a class="nav-link" href="/top-chefs">TOP CHEFS</a>
        </li>
        <li>
            <a class="nav-link" href="/top-contributors">TOP CONTRIBUTORS</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/guest-chef">GUEST CHEF</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/community">COMMUNITY</a>
        </li>
    </div>
    <?php echo $__env->yieldContent('content-home'); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/layouts/home_menu.blade.php ENDPATH**/ ?>