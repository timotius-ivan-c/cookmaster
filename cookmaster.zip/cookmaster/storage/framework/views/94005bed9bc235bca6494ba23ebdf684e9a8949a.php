
<?php $__env->startSection('content-home'); ?>

<h4 class="text-center">Guest Chef</h4>
<div class="text-center">
    <img src="<?php echo e(asset('storage/'.$recipe->image)); ?>" alt="<?php echo e($recipe->name); ?>" style="margin: 10px">
</div>
<p class="text-center"><?php echo e($recipe->name); ?></p>
<div class="text-center">
    <button type="button" class="btn btn-primary" onclick="window.location.href='/recipe/<?php echo e($recipe->id); ?>'">View Recipe</button>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/guest_chef.blade.php ENDPATH**/ ?>