
<?php $__env->startSection('namapage'); ?>
    class="background-4"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>
<div class="box-content">
<div class="container">
    <?php if(empty($recipes)): ?>
    <div class="card">
        <div class="card-header">
            <button class="btn btn-primary" id="filter-hot"><i class="fa fa-check" id="hot_check" aria-hidden="true"></i> Hot Recipes (Most Reviews)</button>
            <button class="btn btn-outline-dark" id="filter-best"><i class="fa fa-check" id="best_check" aria-hidden="true"></i> Best Recipes (Highest Rating)</button>
        </div>
    </div>
    <?php else: ?>
    <div class="card">
        <div class="card-header">
            Your Recipes:
        </div>
    </div>
    <?php endif; ?>
    
    <br>
    <div id="hot_recipes">
    <?php $__empty_1 = true; $__currentLoopData = $hot_recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
        <div class="card-topup col-md-6 bg-light ml-8" onclick="window.location.href='/recipe/view-recipe/<?php echo e($hot->id); ?>'" style="width: 40rem;">
            <br>
            <img class="card-image-top" src="<?php echo e(asset('storage/'.$hot->image)); ?>"> 
            <div class="card-body">   
                <div class="card-title"><strong><?php echo e($hot->name); ?></strong></div>
                <div class="card-text">        
                    Average rating  : <br>
                    <?php echo e($hot->average_rating); ?> / 5.00 <br> from <?php echo e($hot->review_count); ?> people <br><br>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
    <?php endif; ?>
    </div>

    <div id="best_recipes">
    <?php $__empty_1 = true; $__currentLoopData = $best_recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
        <div class="card-topup col-md-6 bg-light ml-8" onclick="window.location.href='/recipe/view-recipe/<?php echo e($best->id); ?>'" style="width: 40rem;">
            <br>
            <img class="card-image-top" src="<?php echo e(asset('storage/'.$best->image)); ?>"> 
            <div class="card-body">   
                <div class="card-title"><strong><?php echo e($best->name); ?></strong></div>
                <div class="card-text">        
                    Average rating  : <br>
                    <?php echo e($best->average_rating); ?> / 5.00 <br> from <?php echo e($best->review_count); ?> people <br><br>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>            
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
    <br>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
        <div class="card-topup col-md-6 bg-light ml-8"  style="width: 40rem;">
            <img class="card-image-top" src="<?php echo e(asset('storage/'.$recipe->image)); ?>"> 
            <div class="card-body">   
                <div class="card-title"><strong><?php echo e($recipe->name); ?></strong></div>
                <div class="card-text">        
                    Average rating  : <br>
                    <?php echo e($recipe->average_rating); ?> / 5.00 <br> from <?php echo e($recipe->review_count); ?> people <br><br>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
    <?php endif; ?>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
<script>
$(document).ready(function(){
    $("#best_recipes").hide();
    $("#best_check").hide();
    $("#filter-hot").click(function(){
        $("#filter-hot").removeClass("btn-outline-dark").addClass("btn-primary");
        $("#filter-best").removeClass("active").addClass("btn-outline-dark").removeClass("btn-primary");
        $('#hot_recipes').show();
        $('#hot_check').show();
        $('#best_recipes').hide();
        $('#best_check').hide();
    });
    $("#filter-best").click(function(){
        $("#filter-hot").removeClass("active").addClass("btn-outline-dark").removeClass("btn-primary");
        $("#filter-best").removeClass("btn-outline-dark").addClass("btn-primary");
        $('#hot_recipes').hide();
        $('#hot_check').hide();
        $('#best_recipes').show();
        $('#best_check').show();
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_best_recipes.blade.php ENDPATH**/ ?>