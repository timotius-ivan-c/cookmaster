
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>
<div class="box-content">
    <?php if($type=='chef'): ?>
    <h5><center>Top 20 Chef</center></h5>
    <?php elseif($type=='contributor'): ?>
    <h5><center>Top 20 Contributor</center></h5>
    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Rank</th>
                <th scope="col">Name</th>
                <th scope="col">Fame</th>
            </tr>
        </thead>
        <tbody>
            <tr class="table-danger">
                <th scope="row">1</th>
                <td onclick="window.location='/profile/<?php echo e($users[0]->id); ?>'"><?php echo e($users[0]->name); ?></td>
                <td><?php echo e($users[0]->fame); ?></td>
            </tr>
            <tr class="table-warning">
                <th scope="row">2</th>
                <td onclick="window.location='/profile/<?php echo e($users[1]->id); ?>'"><?php echo e($users[1]->name); ?></td>
                <td><?php echo e($users[1]->fame); ?></td>
            </tr>
            <tr class="table-info">
                <th scope="row">3</th>
                <td onclick="window.location='/profile/<?php echo e($users[2]->id); ?>'"><?php echo e($users[2]->name); ?></td>
                <td><?php echo e($users[2]->fame); ?></td>
            </tr>
            <?php for($i=3;$i<count($users);$i++): ?>
            <?php $index=$i+1?>
                <tr>
                    <th scope="row"><?php echo e($index); ?></th>
                    <td onclick="window.location='/profile/<?php echo e($users[$i]->id); ?>'"><?php echo e($users[$i]->name); ?></td>
                    <td><?php echo e($users[$i]->fame); ?></td>
                </tr>
            <?php endfor; ?>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/leaderboard.blade.php ENDPATH**/ ?>