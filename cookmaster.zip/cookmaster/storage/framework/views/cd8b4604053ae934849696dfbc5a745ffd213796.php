
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Profile')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-2">
                        <div class="card-body row">
                            <div class="col-md-8">
                                <div>Name: <?php echo e($usr->name); ?></div>
                                <div>Free recipes: <?php echo e($usr->free_recipes_count); ?></div>
                                <div>Paid recipes: <?php echo e($usr->paid_recipes_count); ?></div>
                            </div>
                            <?php if(Auth::user() && Auth::user()->id != $usr->id): ?>
                            <div class="col-md-4 float-right p-2">
                                <div class="float-right">
                                    <?php if($usr->role->name != "Member"): ?>
                                    <button type="button" class="btn btn-primary btn-sm" onclick="window.location='<?php echo e(route('subscribe', $usr->id)); ?>';">Buy Subscription</button>
                                    <?php endif; ?>
                                    <input type="hidden" class = "user_id" name="user_id" value="<?php echo e($usr->id); ?>">
                                    <?php if(count($following)==0): ?>
                                    <button type="button" class="btn btn-success btn-sm searchButton" id="follow" >Follow</button>
                                    <?php else: ?>
                                    <button type="button" class="btn btn-danger btn-sm searchButton" id="follow" >Unfollow</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php elseif(Auth::user() && Auth::user()->id == $usr->id): ?>
                            <div class="col-md-4 float-right p-2">
                                <button class="btn btn-primary" onclick="window.location='/edit-profile/'">Edit Your Profile</button>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card mb-2">
                        <div class="card-header" id="recipes">Recipes:</div>
                        <?php $__empty_1 = true; $__currentLoopData = $usr->recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card-body"><a href="/recipe/view-recipe/<?php echo e($recipe->id); ?>"><?php echo e($recipe->name); ?></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="card-body"><?php echo e(__('No recipe shared yet.')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="card mb-2">
                        <div class="card-header">Subscriptions:</div>
                        <?php $__empty_1 = true; $__currentLoopData = $usr->subscription; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card-body"><?php echo e($sub->start); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="card-body"><?php echo e(__('No subscriptions yet.')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="card mb-2">
                        <div class="card-header">People followed by <?php echo e($usr->name); ?>:</div>
                        <?php $__empty_1 = true; $__currentLoopData = $usr->following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card-body"><a href="/profile/<?php echo e($fol->id); ?>"><?php echo e($fol->name); ?></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="card-body"><?php echo e(__('No followings yet.')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="card mb-2">
                        <div class="card-header">People following <?php echo e($usr->name); ?>:</div>
                        <?php $__empty_1 = true; $__currentLoopData = $usr->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card-body"><a href="/profile/<?php echo e($fol->id); ?>"><?php echo e($fol->name); ?></a></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="card-body"><?php echo e(__('No followers yet.')); ?></div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php if(Auth::user()): ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script>
        $(document).ready(function(){
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            $("#follow").click(function(){
                $.ajax({
                    /* the route pointing to the post function */
                    url: '/follow',
                    type: 'POST',
                    /* send the csrf-token and the input to the controller */
                    data: {_token: CSRF_TOKEN, message:$(".user_id").val()},
                    dataType: 'JSON',
                    /* remind that 'data' is the response of the AjaxController */
                    success: function (data) {
                        if ($("#follow").text() == 'Follow') {
                            $("#follow").html('Unfollow');
                            $("#follow").addClass("btn-danger").removeClass("btn-success");
                            $("#follow_msg").html("Followed!");
                        } else {
                            $("#follow").html('Follow');
                            $("#follow").addClass("btn-success").removeClass("btn-danger");
                            $("#follow_msg").html("Unfollowed!");
                        }
                    }
                }); 
            });
       });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_user_profile.blade.php ENDPATH**/ ?>