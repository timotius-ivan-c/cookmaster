
<?php $__env->startSection('namapage'); ?>
    class="background-2"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="box-content-form">
    <?php if($step == 0): ?>
    <!-- disini user mau masukin judul, foto, tipe, dan kategori resep -->
    <form method="post" action="/new-recipe" enctype="multipart/form-data">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($msg); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Recipe Name</label>
            <input type="text" class="form-control" id="pw" placeholder="Input recipe title . . ." name="name">
          </div>

        <br><img id="image_show" src="">
        <div class="form-group">
            <label for="upload-file" class="browse-label">Recipe Image</label>
            <div class="">
                <input type="file" class="form-control-file x" id="upload-file" name="image" onchange="readURL(this)">
            </div>
        </div>

        <div class="form-group">
            <label for="type">Recipe Type</label>
            <select name="type" id="type">
                <option value="">--- Choose ---</option>
                <option value="1">Free Recipe</option>
                <option value="2">Paid Recipe</option>
            </select>
        </div>

        <div class="form-group">
            <label for="category">Recipe Category</label>
            <select name="category" id="category">
                <option value="">--- Choose ---</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <input type="hidden" name="step" value="0">

        <button type="submit" class="btn btn-primary">Next >></button>
        <button type="reset" class="btn btn-danger" onclick="history.back()">Cancel</button>
    </form>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/add_recipe.blade.php ENDPATH**/ ?>