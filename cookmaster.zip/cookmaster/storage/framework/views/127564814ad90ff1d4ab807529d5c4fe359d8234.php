
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>
<div class="box-content">
    <h5><center>Transaction History</center></h5>
    <br>
    
    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(!empty($transactions)): ?>
    <table class="table col-lg-12">
        <thead>
            <tr class="table-active">
                <td>Transaction ID</td>
                <td>Date</td>
                <td>Token</td>
                <td>Amount</td>
                <td>Description</td>
            </tr>
        </thead>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($transaction->id); ?></td>
            <td><?php echo e($transaction->date); ?></td> 
            <td><?php echo e($transaction->token); ?></td>
            <td><?php echo e($transaction->amount); ?></td> 
            <td><?php echo e($transaction->message); ?></td>
            </tr>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="card-body" style="width: 25rem;"><center>You don't have any transaction.</center></div>
    <?php endif; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_transaction_history.blade.php ENDPATH**/ ?>