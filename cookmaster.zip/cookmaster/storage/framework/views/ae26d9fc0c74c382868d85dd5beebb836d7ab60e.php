
<?php $__env->startSection('namapage'); ?>
    class="background-4"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Recipes with ').$filter.': '.$query); ?></div>

                <div class="alert alert-info"><?php echo e(__('Click on any card to view the full recipe')); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if(Auth::check()): ?>
                    <div class="card mb-5">
                        <div class="card-header bg-warning">Paid Recipes from Your Subscriptions</div>
                        <?php $__empty_1 = true; $__currentLoopData = $recipes_paid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card m-2" onclick="window.location='/recipe/view-recipe/<?php echo e($recipe->id); ?>'">
                            <div class="card-header"><a href="/recipe/view-recipe/<?php echo e($recipe->id); ?>"><?php echo e($recipe->name); ?></a></div>
                            <div class="card-body">
                                <div>Author: <a href="/profile/<?php echo e($recipe->user->id); ?>"><?php echo e($recipe->user->name); ?></a></div>
                                <div>Rating: <?php echo e($recipe->average_rating); ?> / 5</div>
                                <div>Reviews: <?php echo e($recipe->review_count); ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="card-body"><?php echo e(__('No results')); ?></div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header bg-danger">Free Recipes</div>
                        <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card m-2" onclick="window.location='/recipe/view-recipe/<?php echo e($recipe->id); ?>'">
                            <div class="card-header"><a href="/recipe/view-recipe/<?php echo e($recipe->id); ?>"><?php echo e($recipe->name); ?></a></div>
                            <div class="card-body">
                                <div>Author: <a href="/profile/<?php echo e($recipe->user->id); ?>"><?php echo e($recipe->user->name); ?></a></div>
                                <div>Rating: <?php echo e($recipe->average_rating); ?> / 5</div>
                                <div>Reviews: <?php echo e($recipe->review_count); ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="card-body"><?php echo e(__('No results')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_filtered_recipes.blade.php ENDPATH**/ ?>