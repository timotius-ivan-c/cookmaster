
<?php $__env->startSection('content'); ?>
<div>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            <div class="alert-success" id="follow_msg"></div>
                <div class="card-header"><?php echo e(__('Profile')); ?></div>

                <div class="card-body">
                    <div class="alert alert-warning"><?php echo e(__('You are viewing profile page!')); ?></div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>Name: <?php echo e($usr->name); ?></div>
                        <div>Free recipes: <?php echo e($usr->free_recipes_count); ?></div>
                        <div>Recipes:</div>
                        <div class="card">
                            <?php $__empty_1 = true; $__currentLoopData = $usr->recipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card-body"><?php echo e($recipe->name); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="card-body"><?php echo e(__('No recipe shared yet.')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div>Subscriptions:</div>
                        <div class="card">
                            <?php $__empty_1 = true; $__currentLoopData = $usr->subscription; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card-body"><?php echo e($sub->start); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="card-body"><?php echo e(__('No subscriptions yet.')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div>People followed by <?php echo e($usr->name); ?>:</div>
                        <div class="card">
                            <?php $__empty_1 = true; $__currentLoopData = $usr->following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card-body"><?php echo e($fol->name); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="card-body"><?php echo e(__('No followings yet.')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div>People following <?php echo e($usr->name); ?>:</div>
                        <div class="card">
                            <?php $__empty_1 = true; $__currentLoopData = $usr->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="card-body"><?php echo e($fol->name); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="card-body"><?php echo e(__('No followers yet.')); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

    <input type="hidden" class = "user_id" name="user_id" value="<?php echo e($user[0]->id); ?>">
    <?php if(count($following)==0): ?>
    <button type="button" class=" btn-success btn-sm searchButton" id="follow" >Follow</button>
    <?php else: ?>
    <button type="button" class=" btn-danger btn-sm searchButton" id="follow" >Unfollow</button>
    <?php endif; ?>
    <div class="writeinfo"></div> 
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script>
        $(document).ready(function(){
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            $("#follow").click(function(){
                $.ajax({
                    /* the route pointing to the post function */
                    url: '/follow',
                    type: 'POST',
                    /* send the csrf-token and the input to the controller */
                    data: {_token: CSRF_TOKEN, message:$(".user_id").val()},
                    dataType: 'JSON',
                    /* remind that 'data' is the response of the AjaxController */
                    success: function (data) {
                        if ($("#follow").text() == 'Follow') {
                            $("#follow").html('Unfollow');
                            $("#follow").addClass("btn-danger").removeClass("btn-success");
                            $("#follow_msg").html("Followed!");
                        } else {
                            $("#follow").html('Follow');
                            $("#follow").addClass("btn-success").removeClass("btn-danger");
                            $("#follow_msg").html("Unfollowed!");
                        }
                    }
                }); 
            });
       });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/test_follow.blade.php ENDPATH**/ ?>