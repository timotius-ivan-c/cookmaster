
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box-content-topup">
<div class="container">
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

        <div class="card-topup bg-light" style="width: 20rem;">
            <div class="card-body">
                <h5 class="card-title">Chef Information</h5>
                <p class="card-text">Name: <br><?php echo e($chef->name); ?></p>
                <p class="card-text">Type: <br><?php echo e($chef->role->name); ?></p>
                <p class="card-text">Paid recipes count: <br><?php echo e(count($chef->paid_recipe)); ?></p>
            </div>
        </div>
    <br>
    <br>    

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>

    <div class=" card-topup bg-light" style="width: 20rem;">
        <div class="card-body">
            <h5 class="card-title">Subscription Form</h5>
        <form action='/subscribe' method='post'>
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo e($chef->id); ?>">

                <label for="duration">Duration:</label>
                <select class="custom-select" name="duration" id="select">
                    <option selected value=0>Choose Duration</option>
                    <option value=1>1 month</option>
                    <option value=3>3 months</option>
                    <option value=6>6 months</option>
                    <option value=12>12 months</option>
                    <option value=24>24 months</option>
                </select>

                <div class="h5" id="total">Total Price: - </div>
                <div class="h6">Your Balance: <?php echo e($member->balance); ?></div>

                <?php if($errors->any()): ?>
                    <div class="errors"><?php echo e(implode('', $errors->get('duration'))); ?></div>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary">Subscribe</button>
            <button onclick="history.back()" type="reset" class="btn btn-danger">Cancel</button>
        </form>
        </div>
    </div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $('#select').on('change', function() {
        var duration = $('#select').find(":selected").val();
        <?php if($chef->role->name == 'Chef'): ?>
            $('#total').html('Total Price: ' + (30000*duration));
        <?php elseif($chef->role->name == 'Contributor'): ?>
            $('#total').html('Total Price: ' + (15000*duration));
        <?php endif; ?>
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_subscribe_page.blade.php ENDPATH**/ ?>