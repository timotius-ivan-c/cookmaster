
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-home'); ?>
<div class="container">
<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card col-md-3 bg-light ml-5" style="width: 24rem;">
            <div onclick="window.location='/recipe/view-recipe/<?php echo e($subscription->recipe->first()->id); ?>'">
                <img class="img-thumbnail" src="<?php echo e(asset('storage/'.$subscription->recipe->first()->image)); ?>">
                <div class="card-body">Latest Recipe: <br><strong><a href="/recipe/view-recipe/<?php echo e($subscription->recipe->first()->id); ?>"><?php echo e($subscription->recipe->first()->name); ?></a></strong></div>
            </div>
            <a href="<?php echo e(url('profile', $subscription->chef->id)); ?>" style="text-decoration: none;">
            <div class="card-body">
            <h5 onclick="window.location='<?php echo e(url('profile', $subscription->chef->id)); ?>'" class="card-title"><?php echo e($subscription->chef->name); ?></h5>
            <p class="card-text">
                Duration : <?php echo e($subscription->duration); ?> months<br>
                Starts : <?php echo e($subscription->start); ?><br>
                End : <?php echo e($subscription->end); ?>

            </p>
            </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card bg-light col-md-12">
            <div class="card-body">You are not subscribed to any user.</div>
        </div>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/view_user_subscription.blade.php ENDPATH**/ ?>