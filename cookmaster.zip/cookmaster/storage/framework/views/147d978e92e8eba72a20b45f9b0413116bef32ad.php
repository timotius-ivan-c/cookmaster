
<?php $__env->startSection('namapage'); ?>
    class="background-1"
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="box-content">
<h1><strong>Financial Report:<br<br><strong></h1>
<h4><br><br><strong>Total Subscribers:</strong><br></h4>
    <h5>    
    <?php if(!empty($count)): ?>
    <?php echo e($count); ?>

    <?php else: ?>
    0
    <?php endif; ?>
     people
</h5>
<h4><br><strong>Total Income:</strong><br></h4>
    <h5>
    <?php if(!empty($total_earnings)): ?>
    Rp. <?php echo e($total_earnings); ?>

    <?php else: ?>
    Rp. 0
    <?php endif; ?>
    </h5>
<br>
<br>
<?php if(!$transaction_details->isEmpty()): ?>
    <h4><strong>Transaction Details: </strong><br><br></h4>
    <table class="table table-light table-hover table-striped col-lg-12">
        <thead>
            <tr>
                <td>TransactionID</td>
                <td>Amount</td>
                <td>Info</td>
            </tr>
        </thead> 
        <tbody>
            
            <?php $__currentLoopData = $transaction_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hello): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($hello->id); ?></td>
                <td>Rp. <?php echo e($hello->amount); ?></td>
                <td><?php echo e($hello->message); ?></td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
    There is no transaction details!
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timot\OneDrive\Documents\Cookmaster\cookmaster\cookmaster\resources\views/earning.blade.php ENDPATH**/ ?>